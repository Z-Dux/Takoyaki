https://github.com/foo123/RegexAnalyzer/issues/1#issuecomment-750039255

> The (implied) license is as free as it can get. You can modify it and use
> it anywhere you want if it suits you.
> 
> An attribution to original author would be appreciated but even this is not
> mandatory.
> 
> Copy Left

References:

- https://en.wikipedia.org/wiki/Copyleft
- http://gplv3.fsf.org/wiki/index.php/Compatible_licenses
